package vn.iotstar.controller.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class RolePagesController {

	@GetMapping("/manager/index")
	public String managerPage(HttpSession session, Model model) {
		model.addAttribute("role", session.getAttribute("ROLE"));
		return "manager/index";
	}

	@GetMapping("/user/index")
	public String userPage(HttpSession session, Model model) {
		model.addAttribute("role", session.getAttribute("ROLE"));
		return "user/index";
	}
}


