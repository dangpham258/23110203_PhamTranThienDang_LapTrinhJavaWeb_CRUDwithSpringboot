package vn.iotstar.controller.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import vn.iotstar.service.UserService;

@Controller
@RequestMapping("/web")
public class AuthController {

	@Autowired
	private UserService userService;

	@GetMapping("/register")
	public String registerForm() {
		return "web/register";
	}

	@PostMapping("/register")
	public String register(@RequestParam String username,
			@RequestParam String password,
			@RequestParam String confirmPassword,
			@RequestParam(required = false) String fullname,
			RedirectAttributes redirect) {
		try {
			if (!password.equals(confirmPassword)) {
				throw new IllegalArgumentException("Xác nhận mật khẩu không trùng khớp");
			}
			userService.register(username, password, fullname);
			redirect.addFlashAttribute("message", "Đăng ký thành công. Vui lòng đăng nhập.");
			return "redirect:/web/login";
		} catch (Exception e) {
			redirect.addFlashAttribute("error", e.getMessage());
			return "redirect:/web/register";
		}
	}

	@GetMapping("/change-password")
	public String changePasswordForm() {
		return "web/change-password";
	}

	@PostMapping("/change-password")
	public String changePassword(@RequestParam String username,
			@RequestParam String newPassword,
			@RequestParam String confirmPassword,
			RedirectAttributes redirect) {
		try {
			userService.changePassword(username, newPassword, confirmPassword);
			redirect.addFlashAttribute("message", "Đổi mật khẩu thành công.");
			return "redirect:/web/login";
		} catch (Exception e) {
			redirect.addFlashAttribute("error", e.getMessage());
			return "redirect:/web/change-password";
		}
	}
}


