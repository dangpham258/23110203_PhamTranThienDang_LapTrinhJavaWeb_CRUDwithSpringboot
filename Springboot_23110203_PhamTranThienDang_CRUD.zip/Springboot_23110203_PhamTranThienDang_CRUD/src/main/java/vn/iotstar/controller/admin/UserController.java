package vn.iotstar.controller.admin;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import vn.iotstar.entity.User;
import vn.iotstar.model.UserModel;
import vn.iotstar.service.UserService;

@Controller
@RequestMapping("/admin/accounts")
public class UserController {

	@Autowired
	UserService service;

	@GetMapping
	public String list(ModelMap model,
			@RequestParam(name = "page", required = false, defaultValue = "0") int page,
			@RequestParam(name = "size", required = false, defaultValue = "5") int size) {
		Pageable pageable = PageRequest.of(Math.max(page, 0), Math.max(size, 1));
		Page<User> p = service.findByUsernameContaining("", pageable);
		model.addAttribute("users", p.getContent());
		model.addAttribute("currentPage", p.getNumber());
		model.addAttribute("totalPages", p.getTotalPages());
		model.addAttribute("pageSize", p.getSize());
		return "admin/accounts/list";
	}

	@GetMapping("add")
	public String add(ModelMap model) {
		model.addAttribute("user", new UserModel());
		return "admin/accounts/add";
	}

	@GetMapping("edit/{id}")
	public String edit(ModelMap model, @PathVariable("id") Long id) {
		var entity = service.findById(id).orElseThrow();
		var dto = new UserModel();
		BeanUtils.copyProperties(entity, dto);
		dto.setIsEdit(true);
		model.addAttribute("user", dto);
		return "admin/accounts/add";
	}

	@PostMapping("saveOrUpdate")
	public String saveOrUpdate(@ModelAttribute("user") UserModel dto, RedirectAttributes redirectAttributes) {
		User entity;
		boolean isEdit = Boolean.TRUE.equals(dto.getIsEdit());
		
		if (isEdit) {
			entity = service.findById(dto.getUserId()).orElseGet(User::new);
		} else {
			entity = new User();
		}

		if (!isEdit) {
			User existingUser = service.findByUsername(dto.getUsername());
			if (existingUser != null) {
				redirectAttributes.addFlashAttribute("error", "Username đã tồn tại");
				redirectAttributes.addFlashAttribute("user", dto);
				return "redirect:/admin/accounts/add";
			}
		}
		
		entity.setUsername(dto.getUsername());
		entity.setFullname(dto.getFullname());
		entity.setPassword(dto.getPassword());
		entity.setRoleName(dto.getRoleName());
		entity.setActive(dto.isActive());
		
		service.save(entity);
		redirectAttributes.addFlashAttribute("message", 
			isEdit ? "Cập nhật tài khoản thành công" : "Thêm tài khoản thành công");
		return "redirect:/admin/accounts";
	}

	@GetMapping("delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		service.deleteById(id);
		redirectAttributes.addFlashAttribute("message", "Xóa tài khoản thành công");
		return "redirect:/admin/accounts";
	}

	@RequestMapping("search")
	public String search(ModelMap model,
			@RequestParam(name = "q", required = false) String q,
			@RequestParam(name = "page", required = false, defaultValue = "0") int page,
			@RequestParam(name = "size", required = false, defaultValue = "5") int size) {
		String keyword = (q == null) ? "" : q.trim();
		Pageable pageable = PageRequest.of(Math.max(page, 0), Math.max(size, 1));
		Page<User> p;
		if (StringUtils.hasText(keyword)) {
			p = service.findByUsernameContaining(keyword, pageable);
		} else {
			p = service.findByUsernameContaining("", pageable);
		}
		model.addAttribute("users", p.getContent());
		model.addAttribute("currentPage", p.getNumber());
		model.addAttribute("totalPages", p.getTotalPages());
		model.addAttribute("pageSize", p.getSize());
		if (StringUtils.hasText(keyword)) {
			model.addAttribute("q", keyword);
		}
		return "admin/accounts/list";
	}

	@GetMapping("view/{id}")
	public String view(@PathVariable Long id, Model model) {
		User user = service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
		model.addAttribute("user", user);
		return "admin/accounts/view";
	}
}
