package vn.iotstar.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import vn.iotstar.entity.User;
import vn.iotstar.repository.UserRepository;
import vn.iotstar.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository repo;

    // Plaintext passwords per user's request (not recommended for production)

	@Override
	public List<User> findAll() {
		return repo.findAll();
	}

	@Override
	public Optional<User> findById(Long id) {
		return repo.findById(id);
	}

	@Override
	public User save(User u) {
		return repo.save(u);
	}

	@Override
	public void deleteById(Long id) {
		repo.deleteById(id);
	}

	@Override
	public List<User> findByUsernameContaining(String username) {
		return repo.findByUsernameContaining(username);
	}

	@Override
	public Page<User> findByUsernameContaining(String username, Pageable pageable) {
		return repo.findByUsernameContaining(username, pageable);
	}

	@Override
	public List<User> findByFullnameContaining(String fullname) {
		return repo.findByFullnameContaining(fullname);
	}

	@Override
	public User findByUsername(String username) {
		return repo.findByUsername(username);
	}


	@Override
	public User authenticate(String username, String rawPassword) {
		if (username == null || rawPassword == null) return null;
		User u = repo.findByUsername(username);
		if (u == null || !u.isActive()) return null;
        return rawPassword.equals(u.getPassword()) ? u : null;
	}

	@Override
	public User register(String username, String rawPassword, String fullname) {
		if (username == null || username.isBlank() || rawPassword == null || rawPassword.isBlank()) {
			throw new IllegalArgumentException("Username và mật khẩu không được trống");
		}
		User existed = repo.findByUsername(username);
		if (existed != null) {
			throw new IllegalArgumentException("Username đã tồn tại");
		}
		User u = new User();
		u.setUsername(username);
		u.setFullname(fullname);
		u.setActive(true);
		u.setRoleName("USER");
        u.setPassword(rawPassword);
		return repo.save(u);
	}

	@Override
	public void changePassword(String username, String newPassword, String confirmPassword) {
		if (username == null || username.isBlank()) {
			throw new IllegalArgumentException("Username không hợp lệ");
		}
		if (newPassword == null || newPassword.isBlank()) {
			throw new IllegalArgumentException("Mật khẩu mới không được trống");
		}
		if (!newPassword.equals(confirmPassword)) {
			throw new IllegalArgumentException("Xác nhận mật khẩu không trùng khớp");
		}
		User u = repo.findByUsername(username);
		if (u == null || !u.isActive()) {
			throw new IllegalArgumentException("Tài khoản không tồn tại hoặc bị khóa");
		}
        u.setPassword(newPassword);
		repo.save(u);
	}
}
