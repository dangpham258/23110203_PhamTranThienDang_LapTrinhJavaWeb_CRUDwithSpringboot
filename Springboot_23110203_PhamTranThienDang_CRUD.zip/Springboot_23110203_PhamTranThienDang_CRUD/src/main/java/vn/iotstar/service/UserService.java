package vn.iotstar.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import vn.iotstar.entity.User;

public interface UserService {

	List<User> findByFullnameContaining(String fullname);

	List<User> findByUsernameContaining(String username);
	
	Page<User> findByUsernameContaining(String username, Pageable pageable);

	void deleteById(Long id);

	User save(User u);

	Optional<User> findById(Long id);

	List<User> findAll();
	
	User findByUsername(String username);
	
	User authenticate(String username, String rawPassword);

	User register(String username, String rawPassword, String fullname);

	void changePassword(String username, String newPassword, String confirmPassword);
	
}
