package vn.iotstar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot23110203PhamTranThienDangCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
